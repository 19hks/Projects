import React from 'react';
import ReactDOM from 'react-dom/client';
import { Provider } from 'react-redux';
import './index.css';
import App from './App';
import store from './store/store';


document.title = "POLL APPLICATION";

const link = document.querySelector("link[rel~='icon']") || document.createElement('link');
link.rel = 'icon';
link.href = '/icons/poll(1).png';
document.getElementsByTagName('head')[0].appendChild(link);

const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
   <React.StrictMode >
      <Provider store={store}>
         <App />
      </Provider>
   </React.StrictMode>
);


