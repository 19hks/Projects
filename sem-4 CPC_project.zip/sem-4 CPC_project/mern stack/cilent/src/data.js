import Thumbnail1 from './assets/vote1.jpg';
import Thumbnail2 from './assets/vote2.png';
import Thumbnail3 from './assets/Logo_of_Shiv_Sena.svg.png';
import Candidate1 from './assets/images.jpg';
import Candidate2 from './assets/Amit_Shah.jpg';
import Candidate3 from './assets/J_P_nadda.jpg';
import Candidate4 from './assets/rahul-congress.jpg';
import Candidate5 from './assets/mallikarjjun.jpg';
import Candidate6 from './assets/Ajay_Maken.jpg';
import Candidate7 from './assets/Shinde.jpg';
import Candidate8 from './assets/uddhav-thackeray.jpg';



export const elections =[
    {
        id:"e1",
        title:"BJP-ભારતીય જનતા પાર્ટી",
        description: "BJP is a political party in India and the world's largest political party in terms of the number of members. The Bharatiya Janata Party, 'Indian People's Party', BJP) is a political party in India and one of the two major Indian political parties alongside the Indian National Congress. BJP emerged out from Syama Prasad Mukherjee's Bharatiya Jana Sangh.",
        thumbnail: Thumbnail1,
        candidate: ["c1","c2","c3"],
        voters: []
    },
    {
        id:"e2",
        title:"Congress Party(કોંગ્રેસ)",
        description: "The Indian National Congress is a political party in India. It was founded in 1885 and is one of the two major parties in the country, along with the Bharatiya Janata Party . The Indian National Congress (INC), colloquially the Congress Party, or simply the Congress, is a political party in India with deep roots in most regions of India.",
        thumbnail: Thumbnail2,
        candidate: ["c4","c5","c6"],
        voters: []
    },
    {
        id:"e3",
        title:"Shiv Sena Party",
        description: "Shiv Sena, right-wing Hindu nationalist political party in India founded by Bal Thackeray on June 19, 1966. Its largest following is in Mumbai (Bombay) and other parts of Maharashtra state.",
        thumbnail: Thumbnail3,
        candidate: ["c7","c8","c9"],
        voters: []
    },
]

export const candidates = [
    {
        id: "c1",
        fullName: "નરેન્દ્ર મોદી",
        image: Candidate1,
        motto:`Narendra Damodardas Modi was born on 17 September 1950 to a Gujarati Hindu family of Other Backward Class (OBC) background in Vadnagar, Mehsana district,Bombay State (present-day Gujarat).`,
        voteCount: 240,
        election:"e1",
    },
    {
        id: "c2",
        fullName: "અમિત શાહ",
        image: Candidate2,
        motto:`Soon after Shah joined the ABVP in the year 1983. Later on, he joined the Bharatiya Janata Party (BJP) in 1987, one year before Modi joined the party. He became an activist of the BJP's youth wing, Bharatiya Janata Yuva Morcha (BJYM), in 1987.`,
        voteCount: 120,
        election:"e1",
    },
    {
        id: "c3",
        fullName: "જગત પ્રકાશ નડ્ડા",
        image: Candidate3,
        motto:`Jagat Prakash Nadda (born 2 December 1960) is an Indian lawyer and politician who is serving as the 34th Minister of Health, 25th Minister of Chemicals and Fertilizers since 2024 and 11th President of the Bharatiya Janata Party (BJP) since 2020 and the member of the Rajya Sabha representing Gujarat since 2024.`,
        voteCount: 50,
        election:"e1",
    },
    {
        id: "c4",
        fullName: "Rahul Gandhi",
        image: Candidate4,
        motto:`Rahul Gandhi (born 19 June 1970) is politician and member of the political party Indian National Congress. His great-grandfather was Jawaharlal Nehru, who was India's first Prime-Minister. His grandmother was Indira Gandhi who was India's first woman Prime Minister.`,
        voteCount: 20,
        election:"e2",
    },
    {
        id: "c5",
        fullName: "mallikarjjun Kharge",
        image: Candidate5,
        motto:`Mapanna Mallikarjun Kharge born 21 July 1942 is an Indian lawyer and politician serving as the President of the Indian National Congress since 2022 and Leader of the Opposition in Rajya Sabha since 2021.`,
        voteCount: 15,
        election:"e2",
    },
    {
        id: "c6",
        fullName: "Ajay Maken",
        image: Candidate6,
        motto:`Ajay Maken (born 12 January 1964) is a politician from the Indian National Congress party. He is the treasurer of the All India Congress Committee (AICC) and member of the Congress Working Committee (CWC).`,
        voteCount: 15,
        election:"e2",
    },
    {
        id: "c7",
        fullName: "PK Movie",
        image: Candidate7,
        motto:`Human language is confusing. When humans say they love chicken and fish they don't mean they actually love those animals. They mean they love eating them.`,
        voteCount: 10,
        election:"e3",
    },
    {
        id: "c8",
        fullName: "Lagaan Movie",
        image: Candidate8,
        motto:`Lagaan is a Bollywood blockbuster set in a small village during the British Raj. The movie combines cricket and the colonial past.`,
        voteCount: 290,
        election:"e3",
    },

]

export const voters =[
    {
        id: "v1",
        fullName:"Hiral Kshatri",
        email:"hsk@gmail.com",
        password:"Hiral1405",
        isAdmin: true,
        votedElections: ["e1","e2"]
    },
    {
        id: "v2",
        fullName:"Shailesh Kshatri",
        email:"slk@gmail.com",
        password:"shailesh1307",
        isAdmin: false,
        votedElections: ["e1"]
    },
    {
        id: "v3",
        fullName:"Megha Kshatri",
        email:"msk@gmail.com",
        password:"megha901",
        isAdmin: false,
        votedElections: ["e1","e2"]
    },
    {
        id: "v4",
        fullName:"Sunita Kshatri",
        email:"ssk@gmail.com",
        password:"sunita3010",
        isAdmin: true,
        votedElections: []
    },
    {
        id: "v5",
        fullName:"Mistry Yukta",
        email:"diku@gmail.com",
        password:"yukta801",
        isAdmin: true,
        votedElections: ["e3"]
    },
    {
        id: "v6",
        fullName:"Kosha Paramar",
        email:"kosha@gmail.com",
        password:"kosha27",
        isAdmin: true,
        votedElections: ["e3"]
    },
]