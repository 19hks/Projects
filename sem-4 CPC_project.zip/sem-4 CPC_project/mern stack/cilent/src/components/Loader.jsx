// import React from 'react';
// import Spinner from '../assets/loader.gif';

// const Loader = () => {
//     return (
//         <seaction className ="loader">
//             <div className='loader__container'>
//                 <img src={Spinner} alt="Loading"/>
//             </div>
//         </seaction>
//     )
// }

// export default Loader;