import React, { use, useEffect, useState } from 'react'
import { Link , NavLink} from 'react-router-dom'
import { IoIosMoon } from 'react-icons/io'
import { IoIosSunny } from 'react-icons/io'
import { HiOutlineBars3 } from 'react-icons/hi2'
import { AiOutlineClose } from 'react-icons/ai'

const Navbar = () => {
    const[showNav , setshowNav] = useState(window.innerWidth < 600 ? false : true)
    const[darkTheme , setDarkTheme] = useState(localStorage.getItem('voting-app-theme') || "")

//function to close nav menu on small when menu link is clicked
    const closeNavMenu =()=>{
        if(window.innerWidth < 600){
            setshowNav(false);
        }else{
            setshowNav(true);
        }
    }

//function to chnage theme
    const changeThemeHandle =()=>{
        if(localStorage.getItem('voting-app-theme') == 'dark'){
            localStorage.setItem('voting-app-theme','')
        }else{
            localStorage.setItem('voting-app-theme','dark')
        }
        setDarkTheme(localStorage.getItem('voting-app-theme'))
    }

    useEffect(()=>{
        document.body.className= localStorage.getItem('voting-app-theme')
    },[darkTheme])

  return (
    <nav>
        <div className="container nav__container">
            <Link to="/" className='nav__logo'>POLL</Link>
            <div>
                {showNav &&<menu>
                    <NavLink to="/elections" onClick={closeNavMenu}>Elections</NavLink>
                    <NavLink to="/results" onClick={closeNavMenu}>Results</NavLink>
                    <NavLink to="/logout" onClick={closeNavMenu}>Logout</NavLink>
                </menu>}
                <button className="theme__toggle-btn" onClick={changeThemeHandle}>{darkTheme ? <IoIosSunny /> : <IoIosMoon />}</button>
                <button className="nav__toggle-btn" onClick={()=>
                    setshowNav(!showNav)}>{showNav ? <AiOutlineClose/>:<HiOutlineBars3/>}</button>
            </div>
        </div>
   </nav>
  )
}

export default Navbar